﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kolko_krzyzyk
{
    public partial class Form1 : Form
    {
        int counter = 0; // 0 dla X. 1 dla O
        public Form1()
        {
            InitializeComponent();
        }

        // PRZYCISK.Enabled = false; ----------------------->>>>>> Przycisk nie może zostać ponownie użyty
        private void B1_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B1.Text = "X";
                    counter++;
                B1.Enabled = false;
                Check();                //sprawdź czy ktoś wygrał
            }
            else if (counter == 1)
            {
                B1.Text = "O";
                counter--;
                B1.Enabled = false;
                Check();
            }
        }

        private void B2_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B2.Text = "X";
                counter++;
                B2.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B2.Text = "O";
                counter--;
                B2.Enabled = false;
                Check();
            }
        }

        private void B3_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B3.Text = "X";
                counter++;
                B3.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B3.Text = "O";
                counter--;
                B3.Enabled = false;
                Check();
            }
        }

        private void B4_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B4.Text = "X";
                counter++;
                B4.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B4.Text = "O";
                counter--;
                B4.Enabled = false;
                Check();
            }
        }

        private void B5_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B5.Text = "X";
                counter++;
                B5.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B5.Text = "O";
                counter--;
                B5.Enabled = false;
                Check();
            }
        }

        private void B6_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B6.Text = "X";
                counter++;
                B6.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B6.Text = "O";
                counter--;
                B6.Enabled = false;
                Check();
            }
        }

        private void B7_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B7.Text = "X";
                counter++;
                B7.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B7.Text = "O";
                counter--;
                B7.Enabled = false;
                Check();
            }
        }

        private void B8_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B8.Text = "X";
                counter++;
                B8.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B8.Text = "O";
                counter--;
                B8.Enabled = false;
                Check();
            }
        }

        private void B9_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                B9.Text = "X";
                counter++;
                B9.Enabled = false;
                Check();
            }
            else if (counter == 1)
            {
                B9.Text = "O";
                counter--;
                B9.Enabled = false;
                Check();
            }
        }

        void Check()        //sprawdź zwycięzcę
        {
            //w przypadku remisu
            if(B1.Text!="" && B2.Text != "" && B3.Text != "" && B4.Text != "" && B5.Text != "" && B6.Text != "" && B7.Text != "" && B8.Text != "" && B9.Text != "")
            {
                RESULT.Text = "REMIS";
            }

            //zwycięskie X na ukos
            if(B1.Text=="X" && B5.Text=="X" && B9.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;     
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B3.Text == "X" && B5.Text == "X" && B7.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            //zwycieskie X poziomo
            if (B1.Text == "X" && B2.Text == "X" && B3.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B4.Text == "X" && B5.Text == "X" && B6.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B7.Text == "X" && B8.Text == "X" && B9.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            //zwycieskie X pionowo

            if (B1.Text == "X" && B4.Text == "X" && B7.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B2.Text == "X" && B5.Text == "X" && B8.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B3.Text == "X" && B6.Text == "X" && B9.Text == "X")
            {
                RESULT.Text = "X wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }



            
            
            
            //zwycięskie O na ukos
            if (B1.Text == "O" && B5.Text == "O" && B9.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B3.Text == "O" && B5.Text == "O" && B7.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            //zwycieskie X poziomo
            if (B1.Text == "O" && B2.Text == "O" && B3.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B4.Text == "O" && B5.Text == "O" && B6.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B7.Text == "O" && B8.Text == "O" && B9.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            //zwycieskie X pionowo

            if (B1.Text == "O" && B4.Text == "O" && B7.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B2.Text == "O" && B5.Text == "O" && B8.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }

            if (B3.Text == "O" && B6.Text == "O" && B9.Text == "O")
            {
                RESULT.Text = "O wins";
                B1.Enabled = false;
                B2.Enabled = false;
                B3.Enabled = false;
                B4.Enabled = false;
                B5.Enabled = false;
                B6.Enabled = false;
                B7.Enabled = false;
                B8.Enabled = false;
                B9.Enabled = false;
            }



        }
        private void CLEAR_Click(object sender, EventArgs e)
        {
            RESULT.Text = "";
            B1.Enabled = true;
            B2.Enabled = true;
            B3.Enabled = true;
            B4.Enabled = true;
            B5.Enabled = true;
            B6.Enabled = true;
            B7.Enabled = true;
            B8.Enabled = true;
            B9.Enabled = true;

            B1.Text = "";
            B2.Text = "";
            B3.Text = "";
            B4.Text = "";
            B5.Text = "";
            B6.Text = "";
            B7.Text = "";
            B8.Text = "";
            B9.Text = "";
        }

        private void RESULT_TextChanged(object sender, EventArgs e)
        {

        }






        //============================================================================================================================================================


        // KALKULATOR
        int liczba1 = 0;
        
        string Operation;
        private void ZERO_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "0";
            }
            else
            {
                BOX.Text = BOX.Text + "0";
            }
        }
        private void ONE_Click(object sender, EventArgs e)
        {
            if(BOX.Text=="0" && BOX.Text != null)
            {
                BOX.Text = "1";
            }
            else
            {
                BOX.Text = BOX.Text + "1";
            }
        }

        private void TWO_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "2";
            }
            else
            {
                BOX.Text = BOX.Text + "2";
            }
        }

        private void THREE_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "3";
            }
            else
            {
                BOX.Text = BOX.Text + "3";
            }
        }

        private void FOUR_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "4";
            }
            else
            {
                BOX.Text = BOX.Text + "4";
            }
        }

        private void FIVE_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "5";
            }
            else
            {
                BOX.Text = BOX.Text + "5";
            }
        }

        private void SIX_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "6";
            }
            else
            {
                BOX.Text = BOX.Text + "6";
            }
        }

        private void SEVEN_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "7";
            }
            else
            {
                BOX.Text = BOX.Text + "7";
            }
        }

        private void EIGHT_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "8";
            }
            else
            {
                BOX.Text = BOX.Text + "8";
            }
        }

        private void NINE_Click(object sender, EventArgs e)
        {
            if (BOX.Text == "0" && BOX.Text != null)
            {
                BOX.Text = "9";
            }
            else
            {
                BOX.Text = BOX.Text + "9";
            }
        }

        private void C_CALC_Click(object sender, EventArgs e)
        {
            BOX.Text = "0";
        }

        private void HEX_Click(object sender, EventArgs e)
        {
            int liczba1 = int.Parse(BOX.Text);
            string Change16 = Convert.ToString(liczba1, 16);
            BOX.Text = Change16;
        }

        private void BIN_Click(object sender, EventArgs e)
        {
            int liczba1 = int.Parse(BOX.Text);
            string Change2 = Convert.ToString(liczba1, 2);
            BOX.Text = Change2;   
        }

    }
}
