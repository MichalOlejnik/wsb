﻿namespace kolko_krzyzyk
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.B1 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.B8 = new System.Windows.Forms.Button();
            this.B9 = new System.Windows.Forms.Button();
            this.RESULT = new System.Windows.Forms.TextBox();
            this.CLEAR = new System.Windows.Forms.Button();
            this.C_CALC = new System.Windows.Forms.Button();
            this.HEX = new System.Windows.Forms.Button();
            this.BIN = new System.Windows.Forms.Button();
            this.SEVEN = new System.Windows.Forms.Button();
            this.EIGHT = new System.Windows.Forms.Button();
            this.NINE = new System.Windows.Forms.Button();
            this.FOUR = new System.Windows.Forms.Button();
            this.FIVE = new System.Windows.Forms.Button();
            this.SIX = new System.Windows.Forms.Button();
            this.ONE = new System.Windows.Forms.Button();
            this.TWO = new System.Windows.Forms.Button();
            this.THREE = new System.Windows.Forms.Button();
            this.BOX = new System.Windows.Forms.TextBox();
            this.ZERO = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // B1
            // 
            this.B1.Location = new System.Drawing.Point(7, 68);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(75, 75);
            this.B1.TabIndex = 0;
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // B2
            // 
            this.B2.Location = new System.Drawing.Point(88, 68);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(75, 75);
            this.B2.TabIndex = 0;
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B3
            // 
            this.B3.Location = new System.Drawing.Point(169, 68);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(75, 75);
            this.B3.TabIndex = 0;
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // B4
            // 
            this.B4.Location = new System.Drawing.Point(7, 149);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(75, 75);
            this.B4.TabIndex = 0;
            this.B4.UseVisualStyleBackColor = true;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // B5
            // 
            this.B5.Location = new System.Drawing.Point(88, 149);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(75, 75);
            this.B5.TabIndex = 0;
            this.B5.UseVisualStyleBackColor = true;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // B6
            // 
            this.B6.Location = new System.Drawing.Point(169, 149);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(75, 75);
            this.B6.TabIndex = 0;
            this.B6.UseVisualStyleBackColor = true;
            this.B6.Click += new System.EventHandler(this.B6_Click);
            // 
            // B7
            // 
            this.B7.Location = new System.Drawing.Point(7, 230);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(75, 75);
            this.B7.TabIndex = 0;
            this.B7.UseVisualStyleBackColor = true;
            this.B7.Click += new System.EventHandler(this.B7_Click);
            // 
            // B8
            // 
            this.B8.Location = new System.Drawing.Point(88, 230);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(75, 75);
            this.B8.TabIndex = 0;
            this.B8.UseVisualStyleBackColor = true;
            this.B8.Click += new System.EventHandler(this.B8_Click);
            // 
            // B9
            // 
            this.B9.Location = new System.Drawing.Point(169, 230);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(75, 75);
            this.B9.TabIndex = 0;
            this.B9.UseVisualStyleBackColor = true;
            this.B9.Click += new System.EventHandler(this.B9_Click);
            // 
            // RESULT
            // 
            this.RESULT.Location = new System.Drawing.Point(7, 32);
            this.RESULT.Name = "RESULT";
            this.RESULT.Size = new System.Drawing.Size(237, 20);
            this.RESULT.TabIndex = 1;
            this.RESULT.TextChanged += new System.EventHandler(this.RESULT_TextChanged);
            // 
            // CLEAR
            // 
            this.CLEAR.Location = new System.Drawing.Point(7, 3);
            this.CLEAR.Name = "CLEAR";
            this.CLEAR.Size = new System.Drawing.Size(237, 23);
            this.CLEAR.TabIndex = 2;
            this.CLEAR.Text = "CLEAR";
            this.CLEAR.UseVisualStyleBackColor = true;
            this.CLEAR.Click += new System.EventHandler(this.CLEAR_Click);
            // 
            // C_CALC
            // 
            this.C_CALC.Location = new System.Drawing.Point(374, 63);
            this.C_CALC.Name = "C_CALC";
            this.C_CALC.Size = new System.Drawing.Size(86, 36);
            this.C_CALC.TabIndex = 3;
            this.C_CALC.Text = "C";
            this.C_CALC.UseVisualStyleBackColor = true;
            this.C_CALC.Click += new System.EventHandler(this.C_CALC_Click);
            // 
            // HEX
            // 
            this.HEX.Location = new System.Drawing.Point(466, 63);
            this.HEX.Name = "HEX";
            this.HEX.Size = new System.Drawing.Size(86, 36);
            this.HEX.TabIndex = 3;
            this.HEX.Text = "HEX";
            this.HEX.UseVisualStyleBackColor = true;
            this.HEX.Click += new System.EventHandler(this.HEX_Click);
            // 
            // BIN
            // 
            this.BIN.Location = new System.Drawing.Point(558, 63);
            this.BIN.Name = "BIN";
            this.BIN.Size = new System.Drawing.Size(86, 36);
            this.BIN.TabIndex = 3;
            this.BIN.Text = "BIN";
            this.BIN.UseVisualStyleBackColor = true;
            this.BIN.Click += new System.EventHandler(this.BIN_Click);
            // 
            // SEVEN
            // 
            this.SEVEN.Location = new System.Drawing.Point(374, 102);
            this.SEVEN.Name = "SEVEN";
            this.SEVEN.Size = new System.Drawing.Size(86, 36);
            this.SEVEN.TabIndex = 3;
            this.SEVEN.Text = "7";
            this.SEVEN.UseVisualStyleBackColor = true;
            this.SEVEN.Click += new System.EventHandler(this.SEVEN_Click);
            // 
            // EIGHT
            // 
            this.EIGHT.Location = new System.Drawing.Point(466, 102);
            this.EIGHT.Name = "EIGHT";
            this.EIGHT.Size = new System.Drawing.Size(86, 36);
            this.EIGHT.TabIndex = 3;
            this.EIGHT.Text = "8";
            this.EIGHT.UseVisualStyleBackColor = true;
            this.EIGHT.Click += new System.EventHandler(this.EIGHT_Click);
            // 
            // NINE
            // 
            this.NINE.Location = new System.Drawing.Point(558, 102);
            this.NINE.Name = "NINE";
            this.NINE.Size = new System.Drawing.Size(86, 36);
            this.NINE.TabIndex = 3;
            this.NINE.Text = "9";
            this.NINE.UseVisualStyleBackColor = true;
            this.NINE.Click += new System.EventHandler(this.NINE_Click);
            // 
            // FOUR
            // 
            this.FOUR.Location = new System.Drawing.Point(374, 144);
            this.FOUR.Name = "FOUR";
            this.FOUR.Size = new System.Drawing.Size(86, 36);
            this.FOUR.TabIndex = 3;
            this.FOUR.Text = "4";
            this.FOUR.UseVisualStyleBackColor = true;
            this.FOUR.Click += new System.EventHandler(this.FOUR_Click);
            // 
            // FIVE
            // 
            this.FIVE.Location = new System.Drawing.Point(466, 144);
            this.FIVE.Name = "FIVE";
            this.FIVE.Size = new System.Drawing.Size(86, 36);
            this.FIVE.TabIndex = 3;
            this.FIVE.Text = "5";
            this.FIVE.UseVisualStyleBackColor = true;
            this.FIVE.Click += new System.EventHandler(this.FIVE_Click);
            // 
            // SIX
            // 
            this.SIX.Location = new System.Drawing.Point(558, 144);
            this.SIX.Name = "SIX";
            this.SIX.Size = new System.Drawing.Size(86, 36);
            this.SIX.TabIndex = 3;
            this.SIX.Text = "6";
            this.SIX.UseVisualStyleBackColor = true;
            this.SIX.Click += new System.EventHandler(this.SIX_Click);
            // 
            // ONE
            // 
            this.ONE.Location = new System.Drawing.Point(374, 186);
            this.ONE.Name = "ONE";
            this.ONE.Size = new System.Drawing.Size(86, 36);
            this.ONE.TabIndex = 3;
            this.ONE.Text = "1";
            this.ONE.UseVisualStyleBackColor = true;
            this.ONE.Click += new System.EventHandler(this.ONE_Click);
            // 
            // TWO
            // 
            this.TWO.Location = new System.Drawing.Point(466, 186);
            this.TWO.Name = "TWO";
            this.TWO.Size = new System.Drawing.Size(86, 36);
            this.TWO.TabIndex = 3;
            this.TWO.Text = "2";
            this.TWO.UseVisualStyleBackColor = true;
            this.TWO.Click += new System.EventHandler(this.TWO_Click);
            // 
            // THREE
            // 
            this.THREE.Location = new System.Drawing.Point(558, 186);
            this.THREE.Name = "THREE";
            this.THREE.Size = new System.Drawing.Size(86, 36);
            this.THREE.TabIndex = 3;
            this.THREE.Text = "3";
            this.THREE.UseVisualStyleBackColor = true;
            this.THREE.Click += new System.EventHandler(this.THREE_Click);
            // 
            // BOX
            // 
            this.BOX.Location = new System.Drawing.Point(377, 32);
            this.BOX.Name = "BOX";
            this.BOX.Size = new System.Drawing.Size(266, 20);
            this.BOX.TabIndex = 4;
            this.BOX.Text = "0";
            this.BOX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ZERO
            // 
            this.ZERO.Location = new System.Drawing.Point(466, 225);
            this.ZERO.Name = "ZERO";
            this.ZERO.Size = new System.Drawing.Size(86, 36);
            this.ZERO.TabIndex = 3;
            this.ZERO.Text = "0";
            this.ZERO.UseVisualStyleBackColor = true;
            this.ZERO.Click += new System.EventHandler(this.ZERO_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 314);
            this.Controls.Add(this.BOX);
            this.Controls.Add(this.THREE);
            this.Controls.Add(this.ZERO);
            this.Controls.Add(this.TWO);
            this.Controls.Add(this.SIX);
            this.Controls.Add(this.FIVE);
            this.Controls.Add(this.NINE);
            this.Controls.Add(this.ONE);
            this.Controls.Add(this.EIGHT);
            this.Controls.Add(this.FOUR);
            this.Controls.Add(this.BIN);
            this.Controls.Add(this.SEVEN);
            this.Controls.Add(this.HEX);
            this.Controls.Add(this.C_CALC);
            this.Controls.Add(this.CLEAR);
            this.Controls.Add(this.RESULT);
            this.Controls.Add(this.B9);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Name = "Form1";
            this.Text = "X zaczyna";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.Button B8;
        private System.Windows.Forms.Button B9;
        private System.Windows.Forms.TextBox RESULT;
        private System.Windows.Forms.Button CLEAR;
        private System.Windows.Forms.Button C_CALC;
        private System.Windows.Forms.Button HEX;
        private System.Windows.Forms.Button BIN;
        private System.Windows.Forms.Button SEVEN;
        private System.Windows.Forms.Button EIGHT;
        private System.Windows.Forms.Button NINE;
        private System.Windows.Forms.Button FOUR;
        private System.Windows.Forms.Button FIVE;
        private System.Windows.Forms.Button SIX;
        private System.Windows.Forms.Button ONE;
        private System.Windows.Forms.Button TWO;
        private System.Windows.Forms.Button THREE;
        private System.Windows.Forms.TextBox BOX;
        private System.Windows.Forms.Button ZERO;
    }
}

